# -*- coding: utf-8 -*-
"""
PIQUANT major Version 2

Created on Thursday January 19, 2017
from PIquant_GUI_Calibration and other GUIs
to consolidate everything into one GUI to make
it easier for users and easier to maintain

To work with PIQUANT_subprocess (C++ model code)
This file implements the controller
PIQUANT_graph_app implements the view

PIquant - Quantitative processing of X-ray Fluorescence spectra
Developed for PIXL, the Planetary Instrument for X-ray Lithochemistry

This version is development of a simple GUI for the 
underlying C++ analysis code.
Selects files (with full paths) and other arguments
Then runs the C++ code as a subprocess


@author: W. T. Elam   APL/UW
"""



import sys
import os
import subprocess
import tempfile
import datetime
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
PyQt4_QFileDialog_used = False		# ****  Change to False for PySide and PyQt5
#from PyQt4.QtCore import *
#from PyQt4.QtGui import *
#from PySide.QtCore import *
#from PySide.QtGui import *
from PIQUANT_graph_app import GraphApp 
from data_parser_csv import *
from element_symbol_parser import *
# Get the folder containing this application
path_separator = os.sep
this_application_path = sys.path[0] + path_separator
# Simplify the path for Mac OSX applications to make things easier to find
# Also avoids problem writing to nonexistant folder because of the way py2app loads the start script
path_end = this_application_path.find( '.app/Contents/Resources/');
if( path_end > 0 ):
	this_application_path = this_application_path[ 0 : path_end + 24 ] + "/"
# Simplify the path for Windows 7 (Python 2.7) to avoid putting the subprocess in a zip file
this_application_path = this_application_path.replace( '\\library.zip\\','\\');
#print(this_application_path, "   def ")

# add enum capability
def enum(**enums):
    return type('Enum', (), enums)

		# action choices, that correspond to PIQUANT subprocess sub-commands
Action_list = enum( ENERGY_CAL=1, PLOT=2, PRIMARY=3, CALCULATE=4, CALIBRATE=5,  QUANTIFY=6, EVALUATE=7, MAP=8, FIT_ONE_STD=9, COMPARE=10, BULK_SUM = 11, OPTIC=12 )
sub_commands = [ "", "ene", "plot", "pri", "calc", "cali", "quant", "eval", "map", "fits", "comp", "sum", "optic" ]

windowDims = (1200, 1200)
windowDimsGraph = (1200, 800)



class PIQUANT_Main_Window( QWidget ):

	def __init__(self, title, parent=None):
		# Invoke the base class initializer using the Python super function
		super(PIQUANT_Main_Window, self).__init__(parent)
		self.setWindowTitle(title)
		self.setMinimumSize(windowDims[0], windowDims[1])
		# If the user does an energy calibration, use it instead of any read in from files
		# But only for the specific spectrum calibrated
		self.energy_cal_save = ""

			 
		# Lay out the window
		
		# Use QFormLayout for a stack of labeled controls
		self.form_layout = QFormLayout()
		# Selection buttons for actions, group to make exclusive (one choice only)
		self.select_actions_group = QButtonGroup(self)
		self.energy_cal_button = QRadioButton('Energy Calibration' )
		self.select_actions_group.addButton( self.energy_cal_button, Action_list.ENERGY_CAL )
		self.energy_cal_button.clicked.connect( self.energy_cal_selected )
		self.plot_button = QRadioButton( 'Plot Spectrum' )
		self.select_actions_group.addButton( self.plot_button, Action_list.PLOT )
		self.plot_button.clicked.connect( self.plot_selected )
		self.primary_button = QRadioButton( 'Calculate Primary Spectrum' )
		self.select_actions_group.addButton( self.primary_button, Action_list.PRIMARY )
		self.primary_button.clicked.connect( self.primary_selected )
		self.calc_button = QRadioButton( 'Calculate Full Spectrum' )
		self.select_actions_group.addButton( self.calc_button, Action_list.CALCULATE )
		self.calc_button.clicked.connect( self.calc_selected )
		self.cal_button = QRadioButton( 'Calibrate' )
		self.select_actions_group.addButton( self.cal_button, Action_list.CALIBRATE )
		self.cal_button.clicked.connect( self.cal_selected )
		self.quant_button = QRadioButton( 'Quantify' )
		self.select_actions_group.addButton( self.quant_button, Action_list.QUANTIFY )
		self.quant_button.clicked.connect( self.quant_selected )
		self.eval_button = QRadioButton( 'Evaluate' )
		self.select_actions_group.addButton( self.eval_button, Action_list.EVALUATE )
		self.eval_button.clicked.connect( self.eval_selected )
		self.map_button = QRadioButton( 'Map' )
		self.select_actions_group.addButton( self.map_button, Action_list.MAP )
		self.map_button.clicked.connect( self.map_selected )
		self.compare_button = QRadioButton( 'Compare measured to calculated' )
		self.select_actions_group.addButton( self.compare_button, Action_list.COMPARE )
		self.compare_button.clicked.connect( self.compare_selected )
		self.fit_1_std_button = QRadioButton( 'Fit one standard with plot' )
		self.select_actions_group.addButton( self.fit_1_std_button, Action_list.FIT_ONE_STD )
		self.fit_1_std_button.clicked.connect( self.fit_1_std_selected )
		self.bulk_sum_button = QRadioButton( 'Bulk sum and max. value' )
		self.select_actions_group.addButton( self.bulk_sum_button, Action_list.BULK_SUM )
		self.bulk_sum_button.clicked.connect( self.bulk_sum_selected )
		self.optic_button = QRadioButton( 'Optic Response' )
		self.select_actions_group.addButton( self.optic_button, Action_list.OPTIC )
		self.optic_button.clicked.connect( self.optic_selected )
		
		#	Disabble actions  not yet implementedd  in C++ subproccess
		#	Evaluate last one to be implemented, all action buttons live    May 21, 2019

		# Put the buttons in three horizontal rows
		self.select_actions_row1 = QHBoxLayout()
		self.select_actions_row1.addWidget( self.energy_cal_button )
		self.select_actions_row1.addWidget( self.plot_button )
		self.select_actions_row1.addWidget( self.primary_button )
		self.select_actions_row1.addWidget( self.calc_button )
		self.select_actions_row2 = QHBoxLayout()
		self.select_actions_row2.addWidget( self.compare_button )
		self.select_actions_row2.addWidget( self.optic_button )
		self.select_actions_row2.addWidget( self.cal_button )
		self.select_actions_row2.addWidget( self.eval_button )
		self.select_actions_row3 = QHBoxLayout()
		self.select_actions_row3.addWidget( self.fit_1_std_button )
		self.select_actions_row3.addWidget( self.quant_button )
		self.select_actions_row3.addWidget( self.bulk_sum_button )
		self.select_actions_row3.addWidget( self.map_button )
		self.form_layout.addRow( self.select_actions_row1 )
		self.form_layout.addRow( self.select_actions_row2 )
		self.form_layout.addRow( self.select_actions_row3 )
		
		# Start with all of the file buttons and text boxes disabled until an action is chosen
		# Label and select button for configuration file name
		self.config_file_button = QPushButton('Select ...', self)
		self.config_file_button.clicked.connect( self.select_config_file )
		self.config_file_button.setEnabled( False )
		self.form_layout.addRow('Configuration file', self.config_file_button)
		# Editable line to display selected file name
		self.config_file_box = QLineEdit(self)
		self.config_file_box.setEnabled( False )
		self.form_layout.addRow(self.config_file_box)
		# label and select button for standards file name
		self.stds_file_button = QPushButton('Select ...', self)
		self.stds_file_button.clicked.connect( self.select_stds_file )
		self.stds_file_button.setEnabled( False )
		self.form_layout.addRow('Standards input file', self.stds_file_button)
		# Editable line to display selected file name
		self.stds_file_box = QLineEdit(self)
		self.stds_file_box.setEnabled( False )
		self.form_layout.addRow(self.stds_file_box)
		# Label and select button for calibration file name
		self.cal_file_button = QPushButton('Select ...', self)
		self.cal_file_button.clicked.connect( self.select_cal_file )
		self.cal_file_button.setEnabled( False )
		self.form_layout.addRow('Calibration file', self.cal_file_button)
		self.cal_file_out = False
		# Editable line to display selected file name
		self.cal_file_box = QLineEdit(self)
		self.cal_file_box.setEnabled( False )
		self.form_layout.addRow(self.cal_file_box)
		# label and select button for spectrum file name
		self.spec_file_button = QPushButton('Select ...', self)
		self.spec_file_button.clicked.connect( self.select_spectrum_file )
		self.spec_file_button.setEnabled( False )
		self.form_layout.addRow('Spectrum file', self.spec_file_button)
		# Editable line to display selected file name
		self.spec_file_box = QLineEdit(self)
		self.spec_file_box.setEnabled( False )
		self.form_layout.addRow(self.spec_file_box)
		# Editable line for list of elements
		self.element_box = QLineEdit(self)
		element_list_width = windowDims[0] - 200	# Room for label
		if( element_list_width < 0 ): element_list_width = 0
		self.element_box.setMinimumWidth( element_list_width )
		self.element_box.setEnabled( False )
		self.form_layout.addRow("Element fit controls Fe_[KLMN][ IFX]: ",self.element_box)
		# label and select button for plot file name
		self.plot_file_button = QPushButton('Select ...', self)
		self.plot_file_button.clicked.connect( self.select_plot_file )
		self.plot_file_button.setEnabled( False )
		self.form_layout.addRow('Plot file (optional)', self.plot_file_button)
		# Editable line to display selected file name
		self.plot_file_box = QLineEdit(self)
		self.plot_file_box.setEnabled( False )
		self.form_layout.addRow(self.plot_file_box)
		# label and select button for map file name
		self.map_file_button = QPushButton('Select ...', self)
		self.map_file_button.clicked.connect( self.select_map_file )
		self.map_file_button.setEnabled( False )
		self.form_layout.addRow('map file', self.map_file_button)
		# Editable line to display selected file name
		self.map_file_box = QLineEdit(self)
		self.map_file_box.setEnabled( False )
		self.form_layout.addRow(self.map_file_box)
		# label and select button for log file name
		self.log_file_button = QPushButton('Select ...', self)
		self.log_file_button.clicked.connect( self.select_log_file )
		# Selection buttons for existing or new log file, group to make exclusive (one choice only)
		self.select_log_group = QButtonGroup(self)
		self.existing_log_button = QRadioButton( 'Existing' )
		self.existing_log_button.setChecked( 1 )
		self.select_log_group.addButton( self.existing_log_button, 1 )
		self.new_log_button = QRadioButton( 'New' )
		self.select_log_group.addButton( self.new_log_button, 0 )
		# Need to use a horizontal box layout to get all 3 buttons in the row
		self.select_log_row = QHBoxLayout()
		self.select_log_row.addWidget( self.existing_log_button )
		self.select_log_row.addWidget( self.new_log_button )
		self.select_log_row.addWidget( self.log_file_button )
		self.form_layout.addRow('Log file (optional, always appends)', self.select_log_row)
		# Editable line to display selected file name
		self.log_file_box = QLineEdit(self)
		self.form_layout.addRow(self.log_file_box)
		# Options (for inputs not implemented as GUI yet)
		self.options_box = QLineEdit(self)
		self.options_box.setMinimumWidth( element_list_width )
		self.form_layout.addRow('Command line options: ', self.options_box)
		# Space for program output
		self.term_out_text_edit = QTextEdit(self)
		self.term_out_text_edit.setFixedHeight( windowDims[1] - 500 )
		self.form_layout.addRow(self.term_out_text_edit)
		# Button to analyze the spectrum
		self.analyze_button = QPushButton('Go!', self)
		self.analyze_button.clicked.connect( self.analyze )
		self.analyze_button.setEnabled( False )
		self.form_layout.addRow(self.analyze_button)
		# Set the above layout into the window
		self.setLayout( self.form_layout )
		
		# Actions for the buttons and File menu
	def select_config_file(self):
		# Open a file dialog box to get the file name
		temp = QFileDialog.getOpenFileName(None, 'Open configuration file', '.', 'XRF configuration files (*.msa *.xsp)')
		self.config_file_box.setText( temp[0] )		#	PySide and PyQt5
		if( PyQt4_QFileDialog_used ):
			self.config_file_box.setText( temp )		#	PyQt4

	def select_stds_file(self):
		# Open a file dialog box to get the file name
		temp = QFileDialog.getOpenFileName(None, 'Open standards file', '.', 'XRF standards files (*.txt *.csv)')
		self.stds_file_box.setText( temp[0] )		#	PySide and PyQt5
		if( PyQt4_QFileDialog_used ):
			self.stds_file_box.setText( temp )			#	PyQt4
	
	def select_cal_file(self):
		# Open a file dialog box to set the file name
		# Whether it is an Open box or Save box depends on action button
		temp=[]
		if( self.cal_file_out ): 
			temp = QFileDialog.getSaveFileName(None, 'Choose calibration file', '.', 'TEXT or CSV files (*.txt *.csv)')
		else:
			temp = QFileDialog.getOpenFileName(None, 'Choose calibration file', '.', 'TEXT or CSV files (*.txt *.csv)')
		self.cal_file_box.setText( temp[0] )		#	PySide and PyQt5
		if( PyQt4_QFileDialog_used ):
			self.cal_file_box.setText( temp )			#	PyQt4
		
	def select_spectrum_file(self):
		# Open a file dialog box to get the file name
		temp = QFileDialog.getOpenFileName(None, 'Open spectrum file', '.', 'XRF spectrum files or list file (*.msa *.mca *.mcs *.xsp *.txt)')
		self.spec_file_box.setText( temp[0] )		#	PySide and PyQt5
		if( PyQt4_QFileDialog_used ):
			self.spec_file_box.setText( temp )			#	PyQt4
	
	def select_plot_file(self):
		# Open a file dialog box to get the file name
		#	Allow MSA output instead of plot   July 25, 2018
		temp = QFileDialog.getSaveFileName(None, 'Open plot file', '.', 'XRF plot files or spectrum file (*.csv *.msa)')
		self.plot_file_box.setText( temp[0] )			#	PySide and PyQt5
		if( PyQt4_QFileDialog_used ):
			self.plot_file_box.setText( temp )			#	PyQt4
	
	def select_map_file(self):
		# Open a file dialog box to get the file name
		temp = QFileDialog.getSaveFileName(None, 'Open map file', '.', 'XRF map files (*.csv)')
		self.map_file_box.setText( temp[0] )			#	PySide and PyQt5
		if( PyQt4_QFileDialog_used ):
			self.map_file_box.setText( temp )			#	PyQt4
				
	def select_log_file(self):
		# Open a file dialog box to get the file name
		# Check buttons for existing or new file
		if( self.select_log_group.checkedId() ):
			temp = QFileDialog.getOpenFileName(None, 'Open existing log file', '.', 'TEXT files (*.txt)')
			self.log_file_box.setText( temp[0] )			#	PySide and PyQt5
			if( PyQt4_QFileDialog_used ):
				self.log_file_box.setText( temp )			#	PyQt4
		else:
			#	Create a new file
			temp = QFileDialog.getSaveFileName(None, 'Create new log file', '.', 'TEXT files (*.txt)')
			self.log_file_box.setText( temp[0] )			#	PySide and PyQt5
			if( PyQt4_QFileDialog_used ):
				self.log_file_box.setText( temp )			#	PyQt4

		
		# Actions for the action select buttons
		# Set up enabled vs disabled file select and element list controls
		# These booleans also determine the argument list passed to the subprocess
	def energy_cal_selected( self ):
		#                   config stds   cal    spec  elem   plot  map
		self.set_enabled( [ False, False, False, True, True, False, False ] )
		
	def plot_selected( self ):
		#                   config stds   cal    spec  elem   plot  map
		self.set_enabled( [ False, False, False, True, False, True, False ] )
		
	def primary_selected( self ):
		#                   config stds   cal    spec  elem   plot  map
		self.set_enabled( [ True, False, False, False, False, True, False ] )
		
	def calc_selected( self ):
		#                   config stds   cal    spec  elem   plot  map
		self.set_enabled( [ True, True, False, False, False, True, False ] )
		
	def cal_selected( self ):
		#                   config stds   cal    spec  elem   plot  map
		self.set_enabled( [ True, True, True, False, True, False, False ] )
		self.cal_file_out = True
				
	def quant_selected( self ):
		#                   config stds   cal    spec  elem   plot  map
		self.set_enabled( [ True, False, True, True, True, True, False ] )
		self.cal_file_out = False
		
	def eval_selected( self ):
		#                   config stds   cal    spec  elem   plot  map
		self.set_enabled( [ True, True, True, False, True, False, True ] )
		self.cal_file_out = False
		
	def map_selected( self ):
		#                   config stds   cal    spec  elem   plot  map
		self.set_enabled( [ True, False, True, True, True, False, True ] )
		self.cal_file_out = False
		
	def compare_selected( self ):
		#                   config stds   cal    spec  elem   plot  map
		self.set_enabled( [ True, True, False, True, False, True, False ] )
		self.cal_file_out = False
		
	def fit_1_std_selected( self ):
		#                   config stds   cal    spec  elem   plot  map
		self.set_enabled( [ True, True, False, False, True, True, False ] )
		self.cal_file_out = False
	def bulk_sum_selected( self ):
		#                   config stds   cal    spec  elem   plot  map
		self.set_enabled( [ True, False, True, True, True, True, False ] )
		self.cal_file_out = False
	def optic_selected( self ):
		#                   config stds   cal    spec  elem   plot  map
		self.set_enabled( [ True, True, False, True, True, True, False ] )
		self.cal_file_out = False
		
		

	def set_enabled( self, indices ):
		self.config_file_button.setEnabled( indices[0] )
		self.config_file_box.setEnabled( indices[0] )
		self.stds_file_button.setEnabled( indices[1] )
		self.stds_file_box.setEnabled( indices[1] )
		self.cal_file_button.setEnabled( indices[2] )
		self.cal_file_box.setEnabled( indices[2] )
		self.spec_file_button.setEnabled( indices[3] )
		self.spec_file_box.setEnabled( indices[3] )
		self.element_box.setEnabled( indices[4] )
		self.plot_file_button.setEnabled( indices[5] )
		self.plot_file_box.setEnabled( indices[5] )
		self.map_file_button.setEnabled( indices[6] )
		self.map_file_box.setEnabled( indices[6] )
		self.analyze_button.setEnabled( True )

	def analyze(self):
		error = False
		#	Clear the text box so the user knows when the new calculation ends
		self.term_out_text_edit.setText("")
		# Set up arguments for subprocess - subprocess path must be first
		arguments = [this_application_path + "PIQUANT.exe"]
		# sub-command (be sure an action is chosen from the button group)
		action_id = self.select_actions_group.checkedId()
		if( action_id <= 0 ):
			ret = QMessageBox.warning(None, "An action must be chosen first.",
				"Choose on of the actions from the buttons at the top." )
			error = True
		else:
			arguments.append( sub_commands[ action_id ] )
		# Put full file path arguments in order, but only the ones that are enabled
		# Note that this must match what the sub-command expects
		if( self.config_file_button.isEnabled() ):
			if( len( self.config_file_box.text() ) > 0 ):
				arguments.append( self.config_file_box.text() )
			else:
				ret = QMessageBox.warning(None, "A configuration file is required.",
				"Choose a configuration file using its select button." )
				error = True
		if( self.stds_file_box.isEnabled() ):
			if( len( self.stds_file_box.text() ) > 0 ):
				arguments.append( self.stds_file_box.text() )
			else:
				ret = QMessageBox.warning(None, "A standards list file is required.",
				"Choose a file with the list of standards using its select button." )
				error = True
		if( self.cal_file_box.isEnabled() ):
			if( len( self.cal_file_box.text() ) > 0 ):
				arguments.append( self.cal_file_box.text() )
			else:
				ret = QMessageBox.warning(None, "A calibration file is required.",
				"Choose a calibration file using its select button." )
				error = True
		if( self.spec_file_box.isEnabled() ):
			if( len( self.spec_file_box.text() ) > 0 ):
				arguments.append( self.spec_file_box.text() )
			else:
				ret = QMessageBox.warning(None, "A spectrum file is required.",
				"Choose a spectrum file using its select button." )
				error = True
		if( self.element_box.isEnabled() ):
			arguments.append( self.element_box.text() )
			if( action_id != Action_list.FIT_ONE_STD and action_id != Action_list.CALIBRATE and action_id != Action_list.EVALUATE ):
				if( len( self.element_box.text() ) <= 0  ):
					ret = QMessageBox.warning(None, "An element fit control list is required.",
					"Enter or paste an element list with qualifiers in the text box (separated by commas or blanks)." )
					error = True
		if( self.plot_file_box.isEnabled() ):
			if( len( self.plot_file_box.text() ) > 0 ):
				arguments.append(self. plot_file_box.text() )
				self.plot_file_temp = False
			else:
				# Get a temporary file name (and open it to be sure it's OK)
				[ temp_fd, self.plot_file_temp_name ] = tempfile.mkstemp()
				os.close( temp_fd )
				self.plot_file_temp = True
				arguments.append( self.plot_file_temp_name )
		if( self.map_file_box.isEnabled() ):
			if( len( self.map_file_box.text() ) > 0 ):
				arguments.append( self.map_file_box.text() )
			else:
				ret = QMessageBox.warning(None, "A map file is required.",
				"Choose a map file name using its select button." )
				error = True
		# There is always a terminal output file, which is overwritten
		# Choose a temporary file for this purpose and then copy the contents to the log (if any)
		[ temp_fd, term_file_path ] = tempfile.mkstemp()
		os.close( temp_fd )
		arguments.append( term_file_path )
		# Add the options box to the arguments
		if( len( self.options_box.text() ) > 0 ):
			for temp_arg in self.options_box.text().split( " " ):
				if( len( temp_arg ) <= 0 ):
					continue
				arguments.append( temp_arg )
		if( error ): return None

		# run PIQUANT C++ command line program combined into a single subprocess
		#  argv[0] is the full path to the program (fixed by subprocess call)
		#  argv[1] is the sub-command (corresponds to action list at top of this GUI)
		#  remaining arguments are file names (full path)
		#  or the element list (which may include qualifiers such as emission line choice)
#		print arguments
#		print("Args:: ",  arguments)
		result = subprocess.call( arguments )

#		print( "Result = ", result )
		# Display the terminal output from the code in a window
		term_file_object = open( term_file_path )
		term_file_text = term_file_object.read()
		term_file_object.close()
		self.term_out_text_edit.setText(term_file_text)
		# Append the output to the log file if one is chosen
		if( len( self.log_file_box.text() ) > 0 ) :
			log_file = open( self.log_file_box.text(), 'a' )
			log_file.write( "\n" )
			log_file.write( "\n" )
			log_file.write( "------------------------------------------------------\n" )
			#	Make the date and time more human-readable by replacing T with space
			date_and_time_string = datetime.datetime.now().isoformat()
			log_file.write( "PIQUANT_GUI  Log file entry   Local time: " + date_and_time_string.replace( "T", " " ) + "\n" )
			log_file.write( "Command line arguments: "  + str(arguments) + "\n" )
			log_file.write( term_file_text )
			log_file.close()
		# Remove the temporary file
		if( os.path.isfile( term_file_path ) ):
			os.remove( term_file_path )

		# Save the energy calibration if there is one and put it in the options box
		if( action_id == Action_list.ENERGY_CAL ):
			en_cal_index1 = term_file_text.find( "(-e," )
			en_cal_index2 = term_file_text.find( ")", en_cal_index1 )
			temp_str = self.options_box.text()
			# Remove old energy calibration if there is one
			temp_str = temp_str.replace( self.energy_cal_save, "" )
			self.energy_cal_save = ""
			if( en_cal_index1 > 0 ):
				self.energy_cal_save = term_file_text[ en_cal_index1+1:en_cal_index2 ]
			# Don't add or leave a blank at the beginning
			if( len( temp_str ) <= 0 or temp_str == " " ):
				self.options_box.setText( self.energy_cal_save )
			else:
				self.options_box.setText( temp_str + " " + self.energy_cal_save )

		term_file_text = ""	# Free up some space			
		#	See if the return indicates an error
		if( result != 0 ):
			ret = QMessageBox.warning(None, "Error in processing.",
							"Errors in processing, see text." )
			return None
		# Make the plot if there is one
		if( self.plot_file_box.isEnabled() ) :
			data = []
			spec_file_sep = self.spec_file_box.text().rfind( path_separator )
			spec_line_end = len( self.spec_file_box.text() )
			# Read the plot file (selected file or temporary file)
			data = None
			if( self.plot_file_temp ):
				if( os.path.isfile( self.plot_file_temp_name ) ):
					data, xValHeader, title_line = parse_data_csv( self.plot_file_temp_name ) 
					# Remove the plot file if it was a temporary file
					os.remove( self.plot_file_temp_name )
			else:
				#	Check for MSA output instead of plot   July 25, 2018
				msa_check = self.plot_file_box.text().rfind( ".msa" )
				if( msa_check >= 0 ):
					return None
				msa_check = self.plot_file_box.text().rfind( ".MSA" )
				if( msa_check >= 0 ):
					return None
				if( os.path.isfile( self.plot_file_box.text() ) ): 
					data, xValHeader, title_line = parse_data_csv( self.plot_file_box.text() )
			if(  data != None ):
				xData = data[xValHeader]
				del data[xValHeader]
				yDataDict = data
				graph = GraphApp(title_line, windowDimsGraph, yDataDict, xData, xValHeader)
			else:
				ret = QMessageBox.warning(None, "Error reading plot file.",
							"No plot due to error reading plot file, see text." )
				return None

if __name__ == '__main__':
	# Create the Qt application
	app = QApplication(sys.argv)
#	Get the PIQUANT version for window title bar
	result = subprocess.run( [this_application_path + "PIQUANT.exe","version"], text=True, capture_output=True )
	# Create our main window
	mainWindow = PIQUANT_Main_Window("PIQUANT    Version "+result.stdout)
	# Add a menu bar with only the File menu
	menubar = QMenuBar()
	filemenu = menubar.addMenu('File')
	# Create and add actions to select the spectrum, configuration, and calibration files
	selSpecAction = QAction('Select spectrum file ...', filemenu)
	selSpecAction.triggered.connect(mainWindow.select_spectrum_file)
	filemenu.addAction(selSpecAction)
	selConfigAction = QAction('Select configuration file ...', filemenu)
	selConfigAction.triggered.connect(mainWindow.select_config_file)
	filemenu.addAction(selConfigAction)
	selCalAction = QAction('Select calibration file ...', filemenu)
	selCalAction.triggered.connect(mainWindow.select_cal_file)
	filemenu.addAction(selCalAction)
	filemenu.addSeparator()
	analyzeAction = QAction('Analyze', filemenu)
	analyzeAction.triggered.connect(mainWindow.analyze)
	filemenu.addAction(analyzeAction)
	# Show the main window
	mainWindow.show()

# Exit this process and start the Qt main application
#	which draws the window and responds to user-generated events
	sys.exit(app.exec_())
