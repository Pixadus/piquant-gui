PIQUANT_GUI.py looks in this directory for PIQUANT.exe.

