# -*- coding: utf-8 -*-
"""
Created on Fri Mar 6 13:19:20 2015
Modified on Sep 3, 2015 to use any headers, not just meas, bkg, etc.

Graphs the given data and displays it in a new window.
Allows the user to selectively add/remove lines from the graph,
but initially shows all lines.

@author: Robert Wicks (rlwicks@uw.edu if you have questions!)
"""

from __future__ import print_function
import matplotlib
#matplotlib.rcParams['backend.qt4']='PySide'
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import (
#from matplotlib.backends.backend_qt4agg import (
	FigureCanvasQTAgg as FigureCanvas,
	NavigationToolbar2QT as NavigationToolbar)
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
#from PyQt4.QtCore import *
#from PyQt4.QtGui import *
#from PySide.QtCore import *
#from PySide.QtGui import *

#Subclass of the NavigationToolbar to make the home button's function be
# to zoom out view of graph
class CustomNavigationToolbar(NavigationToolbar):
	def __init__(self, mainWindow, canvas, parent, coordinates=True):
		NavigationToolbar.__init__(self, canvas, parent, coordinates)
		self.mainWindow = mainWindow
		
	#Change the function of the home button to go to the zoomed out view
	def home(self, *args):
		self.mainWindow.useLastAxesBounds = False;
		self.mainWindow.draw()

#The window where a graph with checkboxes appears. The checkboxes are used
# to control which of the given yData's lines to display on the graph.
class GraphApp(QMainWindow):
		#title is the title of the window
		#windowDims is the minimum dimensions of the GraphApp window as a list of size 2
		# where windowDims[0] is the width and windowDims[1] is the height.
		#yDataDict is a map where the name of a line maps to it's corresponding 
		# list of y values. 	  
			# [
			# header1 -> [h1data1, h1data2, ...]
			# header2 -> [h2data1, h2data2, ...]
			# header3 -> [h3data1, h3data2, ...]
			# .
			# .
			# .
			# headerN -> [hNdata1, hNdata2, ...]
			# ]
		#xData is a list of x values that corresponds to every list of y values in
		# yDataDict. In other words, xData and all the values in yDataDict are the same length.
		#parent is the parent of the GraphApp window. Generally it should be left as None.
	def __init__(self, title, windowDims, yDataDict, xData, xLabel, parent=None):
		QMainWindow.__init__(self, parent)
		self.setMinimumSize(windowDims[0], windowDims[1])
		self.setWindowTitle(title[0])
		self.plot_title = title
		self.bkgColor = QColor('#9999C2')
		self.x = xData #a list of x values
		self.x_data_label = xLabel
		self.yDict = yDataDict #a dict from label for the line to a list of 
							   # y values for the line 
		self.shownData = [] #holds all the labels of the lines to be shown,
							 # which correspond to the lists of y values in
							 # self.yDict
		self.init_graph_area()
		self.init_colors()
		self.init_dock()
		
		
	#Sets the default values for colors in self.altColors, 
	# as well as sets self.lastColor index to 0
	def init_colors(self):
		#others that aren't used: Qt.white, Qt.gray
		self.altColors = [Qt.blue, Qt.green, Qt.red, Qt.black, Qt.cyan, Qt.darkCyan, 
						  Qt.red, Qt.darkRed, Qt.magenta, Qt.darkMagenta,
						  Qt.green, Qt.darkGreen, Qt.yellow, Qt.darkYellow,
						  Qt.blue, Qt.darkBlue, Qt.darkGray,
						  Qt.lightGray]
		if self.bkgColor in self.altColors:
			self.altColors.remove(self.bkgColor)
		self.lastColor = -1; #index of last color chosen from self.altColors
							 # will be incremented before use
		
	#Creates a graph area and sets that as the central widget of self	
	def init_graph_area(self):
		self.graphArea = QWidget()
		self.graphArea.setAttribute(Qt.WA_StyledBackground, True)
		self.fig = Figure(dpi=100)
		#encode background color as a string
		color = self.bkgColor.name().encode('ascii', 'ignore')
		#self.fig.set_facecolor(color)
		self.canvas = FigureCanvas(self.fig)
		self.canvas.setParent(self.graphArea)
		self.canvas.setFocusPolicy(Qt.ClickFocus)
		self.canvas.setFocus()
		self.mplToolbar = CustomNavigationToolbar(self, self.canvas, self.graphArea)
		mplPalette = self.mplToolbar.palette()
		mplPalette.setColor(self.mplToolbar.backgroundRole(), self.bkgColor)
		self.mplToolbar.setPalette(mplPalette)
		vbox = QVBoxLayout()
		vbox.addWidget(self.canvas)
		vbox.addWidget(self.mplToolbar)
		vbox.setContentsMargins(0, 0, 0, 0)
		self.graphArea.setLayout(vbox)
		self.setCentralWidget(self.graphArea)
		
	#Creates a dock, creates a checkbox for each line represented by a label
	# in self.yDict, and puts the checkboxes in the dock 
	def init_dock(self):
		#Set all the dock's attributes
		self.dock = QDockWidget(parent=self)
		self.dock.setWindowTitle("Lines:")
		self.dock.setAttribute(Qt.WA_StyledBackground, True) #allows bkg color to be specified
		dPalette = self.dock.palette()
		dPalette.setColor(self.dock.backgroundRole(), self.bkgColor)
		self.dock.setPalette(dPalette)
		self.addDockWidget(Qt.DockWidgetArea(2), #default to dock on R side
						   self.dock)
		
		#Setup contents of dock widget to scroll and have vertical layout
		self.chkboxVLayout = QVBoxLayout()
		self.chkboxVLayout.setSizeConstraint(QLayout.SetMinAndMaxSize)
		self.chkboxContainer = QWidget()
		self.chkboxContainer.setLayout(self.chkboxVLayout)
		self.chkboxScrollArea = QScrollArea()
		self.chkboxScrollArea.setWidget(self.chkboxContainer)
		self.dock.setWidget(self.chkboxScrollArea)
		
		#Make the checkboxes, put them in the dock, set them all the checked
		# and draw them all on the graph
		self.init_checkboxes()
		

	#Adds all the checkboxes to the dock and to self.checkboxes
	# in order: initialChecked, sumName, theRest (the rest are 
	# sorted alphabetically)
	# Sets all the checkboxes to checked and draws all of them on the graph.
	def init_checkboxes(self):
		#Add checkboxes and check all of them	
		self.checkboxes = dict()
		restOfHeaders = sorted( self.yDict.keys() )
		for label in restOfHeaders:
			self.add_checkbox(label)
		#False means: don't update axes to the stored axes min/max 
		# (we do this because we dont have the stored axes min/max yet)
		self.useLastAxesBounds = False;
		self.draw()
		#Set the stored axes min/max to the default plot's bounds	
		self.lastXMinAxes, self.lastXMaxAxes = self.axes.get_xlim()
		self.lastYMinAxes, self.lastYMaxAxes = self.axes.get_ylim()	 
		
	#Creates a new checkbox with the given label, and sets it 
	# to be initially checked.
	# Also adds it to self.chkboxVLayout and self.checkboxes[label]   
	def add_checkbox(self, label):
		checkbox = QCheckBox(label)
		'''All checkboxes will be checked and added to the graph initially
		   setChecked(True) and self.add_line(label) comes before
		   checkbox.stateChanged.connect(method) because we don't want to
		   call the method when we initially set the checkbox to be checked.
		   The method redraws the graph, but when we are adding checkboxes,
		   we don't want to redraw the graph for every checkbox. '''
		checkbox.setChecked(True)
		self.add_line(label)
		checkbox.stateChanged.connect(self.checkbox_state_change)
		#set color of text and background
		checkbox.setAutoFillBackground(True)
		cPalette = checkbox.palette()
		cPalette.setColor(QPalette.WindowText, self.get_color(label)) 
		cPalette.setColor(QPalette.Button, self.bkgColor)
		checkbox.setPalette(cPalette)
		self.chkboxVLayout.addWidget(checkbox)
		self.checkboxes[label] = checkbox
	
	#Event handler for when a checkbox's state is changed (changed
	# from checked to unchecked or vice versa).
	# If the caller checkbox became checked, adds the corresponding line to
	# self.shownData
	# else (the caller checkbox became unchecked), removes the corresponding 
	# line from self.shownData
	# Either way, redraws the graph with the updated self.shownData
	def checkbox_state_change(self, state):
		label = self.sender().text()
		if (state == Qt.Checked):
			self.add_line(label)
		else:
			self.remove_line(label)
		self.draw()
		
	#Add the given label to self.shownData if the label 
	# is not in self.initialChecked and is not self.sumName
	# and redraws the graph
	def add_line(self, label):
		self.shownData.append(label)
		
	#Removes the given label from self.shownData if the label 
	# is not in self.initialChecked and is not self.sumName
	# and redraws the graph
	# Pre: self.shownData contains the given label
	def remove_line(self, label):
		self.shownData.remove(label)
		 
	#Redraws the graph using the lines currently in self.shownData
	# and shows self (the main window)
	# If self.useLastAxesBounds, chooses the axes range to be the range in 
	# self.lastXMinAxes, self.lastXMaxAxes, self.lastYMinAxes, 
	# self.lastYMaxAxes, else lets axes be set to default values
	# (graph has a tight fit on the lines currently being displayed)
	def draw(self):
		self.fig.clear()
		self.axes = self.fig.add_subplot(111)
		self.axes.set_title(self.plot_title, fontsize=14, 
							fontweight='bold', verticalalignment='bottom')
		self.axes.set_xlabel(self.x_data_label)
		self.axes.set_ylabel("Counts")		
		for label in self.shownData: 
			palette = self.checkboxes[label].palette()
			color = palette.color(QPalette.WindowText).name()
			self.axes.plot(self.x, self.yDict[label], color)
		self.axes.margins(0.05)
		if self.useLastAxesBounds:
			self.axes.set_xlim(self.lastXMinAxes, self.lastXMaxAxes)
			self.axes.set_ylim(self.lastYMinAxes, self.lastYMaxAxes) 
		self.canvas.draw()
		#Makes the stored axes bounds change when the user 
		# changes the view with the self.mplToolbar
		self.axes.callbacks.connect('xlim_changed', self.axes_x_bounds_change)
		self.axes.callbacks.connect('ylim_changed', self.axes_y_bounds_change)
		self.show()	
	
		#Event handler for when the navigation toolbar changes the view 
	# on the graph - needs to update the lastX(Max,Min)Axes
	def axes_x_bounds_change(self, ax):
		self.useLastAxesBounds = True;
		self.lastXMinAxes, self.lastXMaxAxes = ax.get_xlim()
		
	#Event handler for when the navigation toolbar changes the view 
	# on the graph - needs to update the lastY(Min,Max)Axes
	def axes_y_bounds_change(self, ax):
		self.useLastAxesBounds = True;
		self.lastYMinAxes, self.lastYMaxAxes = ax.get_ylim()
		
	
	#Returns the color for the line with the given label.
	# label is passed because some labels formerly had fixed, preset colors
	def get_color(self, label):
		#choose colors in order if list in init_colors above
		self.lastColor = (self.lastColor + 1) % len(self.altColors)
		return self.altColors[self.lastColor]	
