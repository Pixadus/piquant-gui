# -*- coding: utf-8 -*-
"""
Created on Thurs Sep 3 2015

Reformats an ASCII file in comma separated value format and separates into columns
Skips over the title line (which is read elsewhere)

EXPECTED FORMAT OF INPUT .CSV FILE:
Title
Xlabel, ySeries1,	  ySeries2,	   ySeries3,   ...
xVal1,	ySeries1Val1,	ySeries2Val1,	 ySeries3Val1,	  ...
xVal2,	ySeries1Val2,	ySeries2Val2,	 ySeries3Val2,	  ...
.
.
. 

Each mapping will be from the header to the list of values below them, 
Also note that whitespace (tabs/spaces) between values does not matter - 
the only part that matters is that the separate values are separated by
 a comma ',', each line is separated by a new line '\n', and each line 
 has the same number of values as the header row 
(the header row is the second line of the file).

An example file (example_data.csv):
This is an example graph for the PIXL Spectrum Graphing Utility!
energies, bkg, meas, fit
1, 23, 10, 20
2, 34,		  6, 33
3, 30,	5, 70
4, 35, 17, 73

Corresponding returned dict:
[
xVal -> [1, 2, 3, 4, 5]
ySeries1 -> [23, 34, 30, 35, 40]
ySeries2 -> [10, 6, 5, 17, 18]
ySeries3 -> [20, 33, 70, 73, 50]
]

For information on dictionaries see https://docs.python.org/2/tutorial/datastructures.html
Scroll down to 5.5 Doctionaries

@author: W. T. Elam   APL/UW
Modified from data_parser.py by Robert Wicks
Modified Sept. 11, 2015 to make parsing more robust
"""

from __future__ import print_function
from PyQt5.QtWidgets import QMessageBox
#from PyQt4.QtGui import QMessageBox
#from PySide.QtGui import QMessageBox

#Returns a dict where the name of a line of data maps to it's corresponding 
# list of y values. There is also a line that maps from the x axis name 
# to a list of the x values.
# 
# [
#  header1 -> [h1data1, h1data2, ...]
#  header2 -> [h2data1, h2data2, ...]
#  header3 -> [h3data1, h3data2, ...]
#  .
#  .
#  .
#  headerN -> [hNdata1, hNdata2, ...]
# ]
def parse_data_csv(rawFileName):
	rawFile = open(rawFileName, 'rU')	# U means universal, interprets all line endings
	#skip over the data's info line
	title_info = rawFile.readline()
	data = dict()
	dataHeaders = []
	header_line = rawFile.readline()
	if( not header_line):
		return None, None, None
	for header in header_line.split(','):
		header = header.strip()
		# Check for duplicate headers and implement reasonable fix
		while( header in dataHeaders ):
			header = header + '_'
		#map from each header to an empty list 
		data[header] = [] 
		#construct a list of data headers so that we can index them 
		# when we add the y values to "data"
		dataHeaders.append(header)
	if( len(dataHeaders) < 2 ):
		ret = QMessageBox.warning(None, "Error reading file.",
				"Only one column in file, need at least 2." )
		return None, None, None
	lineNumber = 2
	rawLine = rawFile.readline()	
	while rawLine:
		#add each y value in the "oldLine" to the map's y values for 
		# the corresponding header
		for index, dataValue in enumerate(rawLine.split(',')):
			if( index >= len(dataHeaders) ):
				continue	# skip any columns that do not have a header
			header = dataHeaders[index]
			#make sure to convert to float so that our y values list is
			# a list of floats 1, 2, ... rather than strings "1", "2", ...
			data[header].append(float(dataValue.strip()))
		rawLine = rawFile.readline()
		lineNumber = lineNumber + 1
	rawFile.close()
	# Error message if there is no data in the file.
	if( lineNumber < 4 ):
		ret = QMessageBox.warning(None, "Error reading file.",
				"End of file reached with no data." )
		return None, None, None
	# dataHeaders[0] is the header for the column in rawDataFile 
	# that contains the x values (order in dict is not consistent)
	return data, dataHeaders[0], title_info
